const logisticModel = require('./../models/logistic');
const _RES_ = require('./../utils/_RES_');
const _CW_ = require('./../CW/user');

var logisticService = {

    /**
     * 添加配置分类
     * @param {*} da 
     */
    async addLogistic(da) {
        console.log(da);
        _RES_.init();
        let res = await logisticModel.addLogistic(da);

        if (res.affectedRows == 1) {
            _RES_.data = 1;
            _RES_.msg = _CW_.BASE_ADD_SUCCESS;
        } else {
            _RES_.data = 0;
            _RES_.msg = _CW_.BASE_ADD_FALSE;
        }
        return _RES_;
    },



    async selectAllLogistic() {
        _RES_.init();
        let res = await await logisticModel.getAllLogistic();
        console.log(res);
        _RES_.data = res;
        return _RES_;

    },
    async selectLogisticByAddress(da) {
        console.log(2);
        _RES_.init();
        let pa = '%'+da.areaId+'%';
        let res = await logisticModel.getLogisticByAddress(pa);
        console.log(res);
        _RES_.data = res;
        return _RES_;

    },

    async delItemLogistic(da) {
        _RES_.init();
        let res = await logisticModel.delItemLogistic(da.id);
        if (res.affectedRows == 1) {
            _RES_.data = 1;
            _RES_.msg = _CW_.BASE_DELETE_SUCCESS;
        } else {
            _RES_.data = 0;
            _RES_.msg = _CW_.BASE_REVISE_FALSE;
        }
        return _RES_;
    },


    async updateLogistic(da) {
        console.log("updateLogistic");
        console.log(da);
        _RES_.init();
        let res = await logisticModel.updateItemLogistic(da);
        if (res.affectedRows == 1) {
            _RES_.data = 1;
            _RES_.msg = _CW_.BASE_REVISE_SUCCESS;
        } else {
            _RES_.data = 0;
            _RES_.msg = _CW_.BASE_REVISE_FALSE;
        }
        return _RES_;
    }

}

module.exports = logisticService;