var backMsg = {
    USER_TEL_ERR:'用户登录名错误',
    USER_NO_EXIST:"该用户不存在",
    USER_PASSWORD_ERR:"密码错误",

    USER_ACCOUNT_EXC:"账户异常请联系管理员！",

    USER_OLD_PASSWORD_ERR:"用户旧密码不正确！",

    USER_EXIST:'该手机号已注册！',
    BASE_ADD_SUCCESS:'添加成功',
    BASE_ADD_FALSE:'添加失败',
    BASE_REVISE_FALSE:'修改失败！',
    BASE_REVISE_SUCCESS:'修改成功',
    BASE_DELETE_SUCCESS:'删除成功',
    BASE_DELETE_FALSE:'删除失败',
    

    
}

module.exports = backMsg;