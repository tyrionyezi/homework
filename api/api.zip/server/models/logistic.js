const dbUtils = require('./../utils/db'); // 引入链接池
const logisticSql = require('./../sql/logistic')

var logisticModels = {

    /**
     * 物质类型分类添加S
     * @param {*} da 
     */
    async addLogistic(da) {
        console.log('Model');
        console.log(da);
        console.log(da.fr_address);
        let timestamp = new Date().getTime();
        console.log(timestamp);
        let result = await dbUtils.query(logisticSql.insertLogistic, [timestamp,da.weight, da.price, da.note, da.fr_name, da.fr_tel, da.fr_address, da.fr_address_detail, da.to_name, da.to_tel, da.to_address, da.to_address_detail, da.material_cate, da.delivery_cate]);
        return result;

    },

    async getAllLogistic() {
        let result = await dbUtils.query(logisticSql.selectAllLogistic);
        return result;
    },

    async getLogisticByAddress(da){
        console.log("getLogisticByAddress："+da);
        let result = await dbUtils.query(logisticSql.selectlogisticByAddress,da);
        return result;
    },

    async delItemLogistic(da) {
        let result = await dbUtils.query(logisticSql.delItemLogistic, da);
        return result;
    },

    async updateItemLogistic(da) {
        let result = await dbUtils.query(logisticSql.updateItemLogistic,[da.price,da.weigth,da.fr_person,da.fr_tel,da.fr_address,da.fr_add_detail,da.to_person,da.to_tel,da.to_address,da.to_add_detail,da.note,da.id]);
        return result;
    }



}

module.exports = logisticModels;