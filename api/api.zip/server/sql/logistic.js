
const logistic = {

      /**
       * 物流分类添加
       */
      insertLogistic: 'INSERT INTO logistics (`id`,weigth,price,note,fr_person,fr_tel,fr_address,fr_add_detail,to_person,to_tel,to_address,to_add_detail,material_kind,deliver_kind,create_time,edit_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())',


      /**
       * 查询
       */
      selectAllLogistic: 'SELECT * FROM logistics WHERE `status` = 1 ORDER BY edit_time',

      selectlogisticByAddress:'SELECT * FROM logistics WHERE to_address LIKE ? AND `status` =1',

      /**
       * 修改 删除 ==逻辑删除
       */
      updateItemLogistic: 'UPDATE logistics SET price = ?, weigth = ?, fr_person = ?, fr_tel = ?, fr_address = ?, fr_add_detail = ?,to_person = ?, to_tel = ?,to_address = ?,to_add_detail= ?,note = ?,edit_time = NOW()WHERE `id` = ?',
      updateDeliveryCategory: 'UPDATE delivery_type SET `name` = ?, `desc`=?, note=?, edit_time = NOW() WHERE id=?',

      delItemLogistic: 'UPDATE logistics SET `status` = 0, edit_time = NOW() WHERE id=?',


}

module.exports = logistic;