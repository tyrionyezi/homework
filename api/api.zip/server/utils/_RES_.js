var _RES_ = {
    msg:"",
    data:"",
    resno: 1,
    isHDa:1,
    init:function(){
        this.msg = "";
        this.data = "";
        this.resno = 1;
        this.isHDa = 1;
    },
}

module.exports = _RES_;